export default function Header() {
  return (
    <header className="bg-blue-700 text-white p-4 shadow">
      <div className="text-2xl font-bold">DraftMyAgreement</div>
    </header>
  )
}
