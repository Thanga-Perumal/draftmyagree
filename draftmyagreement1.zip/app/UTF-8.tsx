export default function Home() {
  return (
    <main>
      <h1>Hello from DraftMyAgreement!</h1>
    </main>
  );
}

